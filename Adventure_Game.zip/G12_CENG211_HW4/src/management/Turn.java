package management;

public class Turn {
    private String idOrName;
    private int attackModifier;
    private int speed;

    public Turn(String idOrName,int speed) {
        this.idOrName = idOrName;
        this.speed = speed;	
    }

    public String getIdOrName() {
        return idOrName;
    }

    public double getAttackModifier() {
        return attackModifier;
    }
    
    public int getSpeed() {
        return speed;
    }

}
