package management;
import java.util.Comparator;

public class Sorting implements Comparator<Turn> {
	@Override
	public int compare(Turn t, Turn t2) {
		return t2.getSpeed() - t.getSpeed();
	}
}
