package management;

public class NotAUniqueNameException extends Exception{
	public NotAUniqueNameException() {
		super("Name is not unique!");
	}
	public NotAUniqueNameException(String message) {
		super(message);
	}
}
