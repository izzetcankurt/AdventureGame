package data;

public class Slime extends Opponents{

	public Slime() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int SpecialAction() {
		int damageDealt = getAttack();
        int currentPoints = getPoints();
        int newPoints = (currentPoints + damageDealt > 150) ? 150 : currentPoints + damageDealt;
        setPoints(newPoints);
        if(getTarget().isGuard()) {
            return damageDealt/4;

        }else {
            return damageDealt;
        }   
    }
}

