package data;

public class Orc extends Opponents {
	public Orc() {
	}

	@Override
	public int SpecialAction() {
		setSkippingNextTurn(true);
		int damageDealt = 2 * getAttack();
		if(getTarget().isGuard()) {
			return damageDealt/4;
		}
		else {
			return damageDealt;
		}
    }
}
