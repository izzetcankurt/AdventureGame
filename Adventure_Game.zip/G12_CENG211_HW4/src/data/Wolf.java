package data;
import java.util.Random;

public class Wolf extends Opponents implements Cloneable {
	private Wolf copy;
	Random random = new Random();
    public Wolf getCopy() {
		return copy;
	}

	public void setCopy(Wolf copy) {
		this.copy = copy;
	}

	public Wolf() {
    }

    @Override
    public int SpecialAction(){
    	double randPossiblity = random.nextDouble();
    	if(randPossiblity<0.2) {
    		try {
        	Wolf copyWolf = (Wolf) this.clone();
        	Integer opponentIdI = Opponents.opponentCounter + 1;
    		String id = opponentIdI.toString();
            copyWolf.opponentId = id;
            setCopy(copyWolf);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    	}
    	
    	return 0;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
