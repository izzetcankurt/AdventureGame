package data;
public class Bow extends Weapons{	
	public Bow() {
		super();
	}
	
	private final int staminaS = 1;
	private final int staminaD = 3;
	public int getStaminaS() {
		return this.staminaS;
	}
	public int getStaminaD() {
		return this.staminaD;
	}
}
