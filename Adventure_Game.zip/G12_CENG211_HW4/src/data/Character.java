package data;
import management.InsufficientStaminaException;
import management.SpecialAlreadyUsedException;

public interface Character<W> {
	public int puch() throws InsufficientStaminaException;
	public <W> int attackWithWeapon(int choice) throws InsufficientStaminaException;
	public void guard();
	public void run();
	public int specialAction() throws SpecialAlreadyUsedException;
}
