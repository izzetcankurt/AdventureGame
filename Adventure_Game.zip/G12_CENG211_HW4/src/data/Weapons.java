package data;
import java.util.Random;

public class Weapons {
	Random random = new Random();
	protected int additionsAttackStat;
	public Weapons() {
		this.additionsAttackStat = random.nextInt(11)+10;
	}
	public int getAdditionsAttackStat() {
		return additionsAttackStat;
	}
}
