package data;
import management.SpecialAlreadyUsedException;

public class Knight<W> extends Human<W> {
		
	public <W> Knight(String name) {
		super(name);
	}
	
	public int specialAction() throws SpecialAlreadyUsedException{
		if(!this.isUsed()) {
			this.setUsed(true);
			this.setSpecialAttack(3);
			this.setSkippingTurn(true);
			return 0;
		}
		else {
			throw new SpecialAlreadyUsedException();
		}
	}
}
