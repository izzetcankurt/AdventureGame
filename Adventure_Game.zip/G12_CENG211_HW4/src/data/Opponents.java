package data;
import java.util.Random;

public abstract class Opponents {
	protected String opponentId;
	protected int points;
	protected int attack;
	protected int speed;
	protected Human<?> target;
	protected boolean guard;
	private boolean skippingNextTurn=false;
	private boolean DoubleNextTurn = false;

	public boolean isSkippingNextTurn() {
		return skippingNextTurn;
	}

	public void setSkippingNextTurn(boolean skippingNextTurn) {
		this.skippingNextTurn = skippingNextTurn;
	}

	public boolean isDoubleNextTurn() {
		return DoubleNextTurn;
	}

	public void setDoubleNextTurn(boolean doubleNextTurn) {
		DoubleNextTurn = doubleNextTurn;
	}
	static int opponentCounter = 0;
	
	public String getOpponentId() {
		return opponentId;
	}

	public void setOpponentId(String opponentId) {
		this.opponentId = opponentId;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public Human<?> getTarget() {
		return target;
	}

	public void setTarget(Human<?> target) {
		this.target = target;
	}
	
	public Opponents() {
		opponentCounter++;
		Integer opponentIdI = opponentCounter;
		String id = opponentIdI.toString();
		this.opponentId = id;
		randomArranger();
	}
	
	public void randomArranger() {
		Random rand = new Random();
		this.points = 50 + rand.nextInt(101);
		this.attack = 5 + rand.nextInt(21);
		this.speed = 1 + rand.nextInt(90);
		
	}
	
	public boolean isGuard() {
		return guard;
	}

	public void setGuard(boolean guard) {
		this.guard = guard;
	}

	public int attack() {
        if (!target.isGuard()) {
            return this.attack ;
            
        } else {
            return this.attack/4;
        }
    }
	
	public void guard() {
	    guard = true;
	}
	
	
	public abstract int SpecialAction();
	public String toString() {
        return "Id: " + this.opponentId + ", Type: " + this.getClass().getSimpleName() + ", Points: " + this.points + ", Attack: " + this.attack + ", Speed: " + this.speed;
    }	
	
}