package data;
import management.SpecialAlreadyUsedException;

public class Squire<W> extends Human<W> {

	public <W> Squire(String name) {
		super(name);
	}
	
	public int specialAction() throws SpecialAlreadyUsedException{
		if(!this.isUsed()) {
			this.setStamina(10);
			if(this.getTarget().isGuard()) {
				int damage = (int) Math.round(0.5 * 0.5 * this.getAttack());
				return damage;
			}
			else {
				int damage = (int) Math.round(0.5 * this.getAttack());
				return damage;
			}
		}
		else {
			throw new SpecialAlreadyUsedException();
		}
	}
}
