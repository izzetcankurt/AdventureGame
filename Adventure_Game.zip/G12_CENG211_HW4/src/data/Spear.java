package data;
public class Spear extends Weapons{
	
	public Spear() {
		super();
	}
	private final int stamina = 2;
	
	public int getStamina() {
		return this.stamina;
	}
	
}
