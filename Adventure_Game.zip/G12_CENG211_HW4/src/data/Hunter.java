package data;
import management.SpecialAlreadyUsedException;

public class Hunter<W> extends Human<W> {
	
	public <W> Hunter(String name) {
		super(name);
	}
	
	public int specialAction() throws SpecialAlreadyUsedException{
		if(!this.isUsed()) {
			this.setDoubleTurnNext(true);
			this.setUsed(true);
			if(this.getTarget().isGuard()) {
				int damage = (int) Math.round(0.5 * 0.5 * this.getAttack());
				return damage;
			}
			else {
				int damage = (int) Math.round(0.5 * this.getAttack());
				return damage;
			}
		}
		else {
			throw new SpecialAlreadyUsedException();
		}
	}
}
