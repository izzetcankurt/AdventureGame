package data;
import java.util.Random;

public class Sword extends Weapons{
	public Sword() {
		super();
	}
	
	private final int stamina = 2;
	
	public int getStamina() {
		return this.stamina;
	}
}
