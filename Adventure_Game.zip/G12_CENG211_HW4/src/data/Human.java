package data;
import java.util.Random;

import management.InsufficientStaminaException;
import management.SpecialAlreadyUsedException;

public class Human<W> implements Character<W> {
	private String name;
	private int points;
	private int stamina;
	private int attack;
	private int speed;
	private boolean guard = false;
	private Opponents target;
	private W W;
	private boolean stand = false;
	public int specialAttack=1;
	private boolean skippingTurn = false;
	private boolean isUsed = false;
	private boolean doubleTurnNext = false;
	private boolean run = false;

	public <W> Human(String name) {
		Random rand = new Random();
		this.name = name;
		this.points = 100 + rand.nextInt(51);
		this.stamina = 10;
		this.attack = 20 + rand.nextInt(21);
		this.speed = 10 + rand.nextInt(90);
	}


	@Override
	public int puch() throws InsufficientStaminaException {
			if(this.getStamina() >= 1) {
				if(target.isGuard()) {
					int damage = (int) Math.round(0.5 * 0.8 * this.attack);
					return damage;
				}
				else {
					int damage = (int) Math.round(0.8 * this.attack);
					return damage;
				}
			}
			else {
				throw new InsufficientStaminaException();
			}
	}

	@Override
	public <W> int attackWithWeapon(int choice) throws InsufficientStaminaException {
		Weapons weapon = (Weapons) W;
		if(weapon instanceof Sword) {
			Sword sword = (Sword) weapon;
			switch(choice) {
			case 1:
				if(this.getStamina() >= sword.getStamina()) {
					this.setStamina(this.getStamina() - sword.getStamina());
					if(target.isGuard()) {
						int damage = (int) Math.round(0.5 * (this.getAttack() + sword.getAdditionsAttackStat()));
						return damage;
					}
					else {
						return this.getAttack() + sword.getAdditionsAttackStat();
					}
				}
				else {
					throw new InsufficientStaminaException();
				}
			case 2:
				if(this.getStamina() >= sword.getStamina()) {
					this.setStamina(this.getStamina() - sword.getStamina());
					Random rand = new Random();
					if(target.isGuard()) {
						if(rand.nextInt(100)<25) {
							return 0;
						}
						else {
							int damage = (int) 0.5* 2 *(this.getAttack() + sword.getAdditionsAttackStat());
							return damage;
						}
					}
					else {
						return 2 *(this.getAttack() + sword.getAdditionsAttackStat());
					}
				}
				else {
					throw new InsufficientStaminaException();
				}
			}
		}
		else if(weapon instanceof Spear) {
			Spear spear = (Spear) weapon;
			switch(choice) {
			case 1:
				if(this.getStamina() >= spear.getStamina()) {
					this.setStamina(this.getStamina() - spear.getStamina());
					if(target.isGuard()) {
						int damage = (int) Math.round(0.5 * 1.1 * (this.getAttack() + spear.getAdditionsAttackStat()));
						return damage;
					}
					else {
						int damage = (int) Math.round(1.1 * (this.getAttack() + spear.getAdditionsAttackStat()));
						return damage;
					}
				}
				else {
					throw new InsufficientStaminaException();
				}
			case 2:
				if(this.getStamina() >= spear.getStamina()) {
					this.setStamina(this.getStamina() - spear.getStamina());
					if(target.isGuard()) {
						this.stand = true;
						int damage = (int) 0.5* 2 *(this.getAttack() + spear.getAdditionsAttackStat());
						return damage;
					}
					else {
						this.stand = true;
						return 2 *(this.getAttack() + spear.getAdditionsAttackStat());
					}
				}
				else {
					throw new InsufficientStaminaException();
				}
			}
		}
		else {
			Bow bow = (Bow) weapon;
			switch(choice) {
			case 2:
				if(this.getStamina() >= bow.getStaminaD()) {
					this.setStamina(this.getStamina() - bow.getStaminaD());
					if(target.isGuard()) {
						int damage = (int) (0.5* 0.8 *(this.getAttack() + bow.getAdditionsAttackStat()));
						return damage;
					}
					else {
						int damage = (int) (0.8 *(this.getAttack() + bow.getAdditionsAttackStat()));
						return damage;
					}
				}
				else {
					throw new InsufficientStaminaException();
				}
				
			case 1:
				if(this.getStamina() >= bow.getStaminaS()) {
					this.setStamina(this.getStamina() - bow.getStaminaS());
					if(target.isGuard()) {
						int damage = (int) (0.5* 2.5 *(this.getAttack() + bow.getAdditionsAttackStat()));
						return damage;
					}
					else {
						int damage = (int) (2.5 *(this.getAttack() + bow.getAdditionsAttackStat()));
						return damage;
					}
				}
				else {
					throw new InsufficientStaminaException();
				}
			
			}
		}
		return 0;
	}

	@Override
	public void guard() {
		this.guard = true;
		this.setStamina(getStamina() + 3);
	}
	
	public boolean isGuard() {
		return guard;
	}
	
	@Override
	public void run() {
		System.out.println("Your character(s) started running away. The battle ends!\r\n"
				+ "Thanks for playing!\r\n");
		this.setRun(true);
		
	}

	public boolean isRun() {
		return run;
	}


	public void setRun(boolean run) {
		this.run = run;
	}
	
	@Override
	public int specialAction() throws SpecialAlreadyUsedException {
		return 0;
		// TODO Auto-generated method stub
		
	}
	public W getW() {
		return W;
	}


	public void setW(W w) {
		W = w;
	}
	public Opponents getTarget() {
		return target;
	}
	
	public boolean isStand() {
		return stand;
	}


	public void setStand(boolean stand) {
		this.stand = stand;
	}


	public boolean isDoubleTurnNext() {
		return doubleTurnNext;
	}


	public void setDoubleTurnNext(boolean doubleTurnNext) {
		this.doubleTurnNext = doubleTurnNext;
	}
	
	public boolean isSkippingTurn() {
		return skippingTurn;
	}


	public void setSkippingTurn(boolean skippingTurn) {
		this.skippingTurn = skippingTurn;
	}


	public boolean isUsed() {
		return isUsed;
	}


	public void setUsed(boolean isUsed) {
		this.isUsed = isUsed;
	}
	
	public void setGuard(boolean guard) {
		this.guard = guard;
	}
	
	public int getSpecialAttack() {
		return specialAttack;
	}


	public void setSpecialAttack(int specialAttack) {
		this.specialAttack = specialAttack;
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getPoints() {
		return points;
	}


	public void setPoints(int points) {
		this.points = points;
	}


	public int getStamina() {
		return stamina;
	}


	public void setStamina(int stamina) {
		this.stamina = stamina;
	}


	public int getAttack() {
		return attack;
	}


	public void setAttack(int attack) {
		this.attack = attack;
	}


	public int getSpeed() {
		return speed;
	}


	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public void setTarget(Opponents target) {
		this.target = target;
	}
	
	public String toString() {
		return this.getName() + " Job : " + this.getClass().getSimpleName() + " Points : " + this.getPoints() +
				" Stamina : " + this.getStamina() + " Attack : " + this.getAttack() + " Speed : " + this.getSpeed() + " Weapon : "
				+ this.getW().getClass().getSimpleName() + " with +" + ((Weapons) this.getW()).getAdditionsAttackStat() +" attack";
	}
	
}
