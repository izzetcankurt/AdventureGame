package data;

public class Goblin extends Opponents {



	public Goblin() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int SpecialAction() {
		int damageDealt = (int) (0.7 * getAttack());
		setDoubleNextTurn(true);
        if(getTarget().isGuard()) {
        	return damageDealt/4;
        }
        else {
    		return damageDealt;
        }
	}
}
