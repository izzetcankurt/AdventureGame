package data;

public class Villager<W> extends Human<W> {
	public <W> Villager(String name) {
		super(name);
	}
	
}
