package main;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;

import data.Bow;
import data.Goblin;
import data.Human;
import data.Hunter;
import data.Knight;
import data.Opponents;
import data.Orc;
import data.Slime;
import data.Spear;
import data.Squire;
import data.Sword;
import data.Villager;
import data.Weapons;
import data.Wolf;
import management.InsufficientStaminaException;
import management.NotAUniqueNameException;
import management.Sorting;
import management.Turn;


public class TBGame {
    private ArrayList<Opponents> opponents;
    private ArrayList<Human> characters;
    private ArrayList<Turn> turnArrList;
    private Queue<Turn> turnOrder;
    
    public TBGame() {
    	this.turnArrList = new ArrayList<Turn>();
        this.opponents = new ArrayList<Opponents>();
        this.characters = new ArrayList<Human>();
        this.turnOrder = new LinkedList<Turn>();
    }
	
    public class Menu {
		private Integer number;
		private int choice;
		Scanner input = new Scanner(System.in);
		Random random = new Random();
		
			 public int numberOfCharacters(){
				 boolean done = false;
				 while(!done) {
					 try {
						 Scanner input2 = new Scanner(System.in);
						 System.out.println("\nPlease enter the number of characters to create: ");
						 number = input2.nextInt();
						 while(number>3 || number<1) {
							 
							 number = input.nextInt();
						 }
						 done = true;
					 }catch(InputMismatchException e) {
						 System.out.println("Invalid input! Please try again... ");
						 Scanner input2 = new Scanner(System.in);
						 System.out.println("\nPlease enter the number of characters to create: ");
						 number = input2.nextInt();
						 while(number>3 || number<1) {
							 
							 number = input.nextInt();
						 }
						 done = true;
					 }
				 }
				 
				 
				 	return number;
				 
			    }
			 
			 public String nameOfYourCharacter(int i) throws NotAUniqueNameException{
			     String fix;
			     String name;
			     boolean done = false;
				 switch (i) {
			            case 1:
			                fix = "st";
			                break;
			            case 2:
			                fix = "nd";
			                break;
			            case 3:
			                fix = "rd";
			                break;
			            default:
			                fix = "th";
			                break;
				 }
				 
				 System.out.print("\nEnter name of your " + i + fix + " character: ");
			     name = input.next();
			     return name;
			 }
			 public void displayStatsOfCharacter(Human<?> h) {
				 h.toString();
			 }
			 
			 public void displayStatsOfOpponent(Opponents o) {
				 System.out.println(o.toString());
				}
			 
			 public void displayTurnOrder() {
				 String turnS = "";
				 for(int i = 0; i<turnArrList.size() ; i++) {
					 turnS += turnArrList.get(i).getIdOrName() + ", ";
				 }
				 System.out.println("***Turn Order : " + (String) turnS + " ***");
			 }
			 
			 public Integer displayHumanMenu() throws InputMismatchException{
				 System.out.println("[1] Punch\r\n"
				 		+ "[2] Attack with weapon\r\n"
				 		+ "[3] Guard\r\n"
				 		+ "[4] Special Action\r\n"
				 		+ "[5] Run");
				 System.out.println("Please select an option between 1-5: ");
				 choice = input.nextInt();
				 while(choice<1 || choice>5) {
					 System.out.println("Please select in given range(1-5) : ");
					 choice = input.nextInt();}
				 Integer choiceI = choice;
				 if(choiceI instanceof Integer) {
					 return choice;}
				 else {
					throw new InputMismatchException();
				 }
			 }
			 
			 public int displayWeaponAttackType(Weapons weapon) {
				 switch(String.valueOf(weapon.getClass()).split(" ")[1]) {
				 case "Sword":
					 System.out.println("Please select weapon attack type ([1] Slash [2] Stab): ");
					 break;
				 case "Spear":
					 System.out.println("Please select weapon attack type ([1] Stab [2] Thrown): ");
					 break;
				 case "Bow":
					 System.out.println("Please select weapon attack type ([1] Single [2] Double): ");
					 break;
				 }
				 choice = input.nextInt();
				 return choice;
			 }
			 
			 public Opponents targetChoice() {
				 Opponents targetOpponent=null;
				 System.out.println("Please enter an opponent id: ");
				 String choice = input.next();
				 for(Opponents o: opponents) {

					 if(o.getOpponentId().equals(choice)) {
						 targetOpponent = o;
					 }
				 }
				 return targetOpponent;
				 
			 }
			 public Human<Weapons> randomTarget(){
				 Human<Weapons> targetHuman=null;
				 int randInt = random.nextInt(characters.size());
				 targetHuman = characters.get(randInt);	 
				 return targetHuman;
			 }
			 
			 public void turnMoveOpp(Opponents o) {
				 if(!o.isSkippingNextTurn()) {
					int attack;
					Random random = new Random();
					o.setTarget(randomTarget());
					int move = random.nextInt(3);
					switch(move) {
					case(0):
						attack = o.attack();
						o.getTarget().setPoints(o.getTarget().getPoints()-(attack));
						
						System.out.println("Opponent " + o.getOpponentId() + " attacks " + o.getTarget().getName() +
								 ". Deals " + attack + " damage.");
						System.out.println(o.getTarget().toString());
						break;
					case(1):
						o.guard();
						System.out.println("Opponent " + o.getOpponentId() + " guards.");
						System.out.println(o.toString());
						break;
					case(2):
						attack = o.SpecialAction();
					System.out.println("Opponent " + o.getOpponentId() + " uses special action on " + 
							o.getTarget().getName() + ". Deals " + attack + " damage.");
					System.out.println(o.getTarget().toString());
						o.getTarget().setPoints(o.getTarget().getPoints()-(attack));
						
						if(o.isDoubleNextTurn()) {
							o.setTarget(randomTarget());
							attack = o.SpecialAction();
							o.getTarget().setPoints(o.getTarget().getPoints()-(attack));
							o.setDoubleNextTurn(false);
						}
						
						break;
					default:
						break;
					} 
				 }
				 else {
					 o.setSkippingNextTurn(false);
				 }
				 
			 }
			 
			 public void bowMenu() {
				 System.out.println("Please select weapon attack type ([1] Single [2] Double): ");
			 }
			 
			 public void spearMenu() {
				 System.out.println("Please select weapon attack type ([1] Stab [2] Thrown): ");
			 }
			 
			 public void swordMenu() {
				 System.out.println("Please select weapon attack type ([1] Slash [2] Stab): ");
			 }
			 
			 public void turnMoveChar(Human<Weapons> hum) {
				 if(hum.isGuard()) {
					 hum.setGuard(false);
				 }
				 if(!hum.isSkippingTurn()) {
					 int choice = displayHumanMenu();
					 switch(choice){
					 case 1:
						 Opponents target = targetChoice();
						 System.out.println(target.getOpponentId());
						 hum.setTarget(target);
						 try {
							 int damage = hum.puch();
							 target.setPoints(target.getPoints() - damage);
							 System.out.println(hum.getName() + " punches Opponent " + target.getOpponentId() +
									 ". Deals " + damage + " damage.");
							 System.out.println(hum.toString());
							 System.out.println(target.toString());
						 }
						 catch(InsufficientStaminaException e) {
							 e.getMessage();
						 }
						 break;
					 case 2:
						 if(!hum.isStand()) {
							 try {
								 Opponents target2 = targetChoice();
								 hum.setTarget(target2);
								 int choose;
								 if(hum.getW() instanceof Sword) {
									 swordMenu();
									 choose = input.nextInt();
									 int damageSw = hum.attackWithWeapon(choose);
									 target2.setPoints(target2.getPoints() - damageSw);
									 System.out.println(hum.getName() + " attacks " + target2.getOpponentId() +
											 ". Deals " + damageSw + " damage.");
									 System.out.println(hum.toString());
									 System.out.println(target2.toString());
								 }
								 else if(hum.getW() instanceof Spear) {
									 spearMenu();
									 choose = input.nextInt();
									 int damageSw = hum.attackWithWeapon(choose);
									 target2.setPoints(target2.getPoints() - damageSw);
									 System.out.println(hum.getName() + " attacks " + target2.getOpponentId() +
											 ". Deals " + damageSw + " damage.");
									 System.out.println(hum.toString());
									 System.out.println(target2.toString());
								 }
								 else if(hum.getW() instanceof Bow){
									 bowMenu();
									 choose = input.nextInt();
									 int damageSw = hum.attackWithWeapon(choose);
									 target2.setPoints(target2.getPoints() - damageSw);
									 System.out.println(hum.getName() + " attacks " + target2.getOpponentId() +
											 ". Deals " + damageSw + " damage.");
									 System.out.println(hum.toString());
									 System.out.println(target2.toString());
								 }
								 else {
									 System.out.println("Something wrong!");
								 }
						 	}
							 catch(Exception e) {
								 e.getMessage();
							 }
						 }
						 
						 else{hum.setStand(false);}
						 break;
					 case 3:
						 hum.guard();
						 System.out.println(hum.getName() + " starts guarding.");
						 System.out.println(hum.toString());
						 break;
					 case 4:
						 try {
						 Opponents target3 = targetChoice();
						 hum.setTarget(target3);
						 int attack = hum.specialAction();
						 hum.getTarget().setPoints(hum.getTarget().getPoints()-(attack));
						 System.out.println("Character " + hum.getName() + " uses special action on Opponent " + 
									target3.getOpponentId() + ". Deals " + attack + " damage.");
						 System.out.println(hum.toString());
						 System.out.println(target3.toString());
						 }
						 catch(Exception e){
							 e.getMessage();
						 }
						 break;
					 case 5:
						 hum.run();
						 break;
					 }
				 }
				 else {
					 hum.setSkippingTurn(false);
				 }
			 }
		
	}
	
    public class Initializer {
		TBGame.Menu menu = new TBGame.Menu();
		Random random = new Random();
		
		public void initializeTurnArrList() {
			for(Opponents o: opponents) {
				Turn turn = new Turn(o.getOpponentId(), o.getSpeed());
				turnArrList.add(turn);
			}
			for(Human<?> h: characters) {
				Turn turn = new Turn(h.getName(), h.getSpeed());
				turnArrList.add(turn);
			}
		}
		
		public void initializeTurnOrder() {
			Collections.sort(turnArrList, new Sorting());
			for(Turn turn: turnArrList) {
				turnOrder.offer(turn);
			}
		}
		public void initializeCharacters() {
			int numOfChar =	menu.numberOfCharacters();
			
			for(int i = 0; i <numOfChar ; i++) {
				String name = "";
				try {
					name = menu.nameOfYourCharacter(i+1);
				} catch (NotAUniqueNameException e) {
					System.out.println(e.getMessage());
				}
				int chooseW = random.nextInt(3);
				Sword sw = new Sword();
				Spear sp = new Spear();
				Bow bw = new Bow();
				switch(chooseW) {
				case 0:
					int chooseX = random.nextInt(4);
					switch(chooseX) {
					case 0:
						Knight<Sword> knight = new Knight<Sword>(name);
						knight.setW(sw);
						characters.add(knight);
						break;
					case 1:
						Hunter<Sword> hunter = new Hunter<Sword>(name);
						characters.add(hunter);
						hunter.setW(sw);
						break;
					case 2:
						Villager<Sword> villager = new Villager<Sword>(name);
						characters.add(villager);
						villager.setW(sw);
						break;
					case 3:
						Squire<Sword> squire = new Squire<Sword>(name);
						characters.add(squire);
						squire.setW(sw);
						break;
					}
					break;
				case 1:
					int chooseY = random.nextInt(4);
					switch(chooseY) {
					case 0:
						Knight<Spear> knight = new Knight<Spear>(name);
						characters.add(knight);
						knight.setW(sp);
						break;
					case 1:
						Hunter<Spear> hunter = new Hunter<Spear>(name);
						characters.add(hunter);
						hunter.setW(sp);
						break;
					case 2:
						Villager<Spear> villager = new Villager<Spear>(name);
						characters.add(villager);
						villager.setW(sp);
						break;
					case 3:
						Squire<Spear> squire = new Squire<Spear>(name);
						characters.add(squire);
						squire.setW(sp);
						break;
					}
					break;
				case 2:
					int chooseZ = random.nextInt(4);
					switch(chooseZ) {
					case 0:
						Knight<Bow> knight = new Knight<Bow>(name);
						characters.add(knight);
						knight.setW(bw);
						break;
					case 1:
						Hunter<Bow> hunter = new Hunter<Bow>(name);
						characters.add(hunter);
						hunter.setW(bw);
						break;
					case 2:
						Villager<Bow> villager = new Villager<Bow>(name);
						characters.add(villager);
						villager.setW(bw);
						break;
					case 3:
						Squire<Bow> squire = new Squire<Bow>(name);
						characters.add(squire);
						squire.setW(bw);
						break;
					}
					break;
				}
				
			}
	    }
		
		public void initializeOpponents() {
			int opponentNumber = 1 + random.nextInt(4);
			for(int i = 0; i < opponentNumber; i++) {
				switch(random.nextInt(4)) {
				case 0:
					Goblin goblin = new Goblin();
					opponents.add(goblin);
					break;
				case 1:
					Orc orc = new Orc();
					opponents.add(orc);
					break;
				case 2:
					Slime slime = new Slime();
					opponents.add(slime);
					break;
				case 3:
					Wolf wolf = new Wolf();
					opponents.add(wolf);
					break;
				}
				
			}
		}

	}
    
    public static void main(String[] args) {
    	TBGame tb = new TBGame();
    	TBGame.Initializer init = tb.new Initializer();
    	System.out.println("Welcome to TBGame!\r\n");
    	System.out.println("These opponents appeared in front of you:\n");
    	
    	init.initializeOpponents();
    	for(Opponents opp: tb.opponents) {
    		System.out.println(opp.toString());
    	}
    	init.initializeCharacters();
    	System.out.println("\nThe stats of your character(s) : ");
    	for(Human chr: tb.characters) {
    		System.out.println(chr.toString());
    	}
    	System.out.println("\nThe battle starts!");
    	init.initializeTurnArrList();
    	init.initializeTurnOrder();
    	int moveCount = 0;
    	boolean check = true;
    	while(check) {
    		
    			Turn turn = tb.turnOrder.peek();
    			moveCount++;
    			String tempNameOrId = turn.getIdOrName();
    			System.out.print("TURN ORDER: ");
    			for(Turn t: tb.turnOrder) {
    				System.out.print(t.getIdOrName() + " ");
    			}
    			System.out.println();
    			System.out.println("--------------------------------------------------------");
    			System.out.println("Move " + moveCount + " - Its the turn of " + tempNameOrId);
    			for(Opponents oppt : tb.opponents) {
    				if(oppt.getOpponentId().equals(tempNameOrId)) {
    					init.menu.turnMoveOpp(oppt);
    					if(oppt.getTarget() != null) {
    						if(oppt.getTarget().getPoints() <= 0) {
    							String name = oppt.getTarget().getName();
    							
    							for(int i = 0; i<tb.turnOrder.size();i++) {
	    							Turn temp2 = tb.turnOrder.poll();
	    							if(name != temp2.getIdOrName()) {	
	    								tb.turnOrder.offer(temp2);
    								}
    							}
    							tb.characters.remove(oppt.getTarget());
    							init.initializeTurnArrList();
    							
    							
    						}
    					}
    					if(oppt instanceof Wolf) {
    						Wolf wolf = (Wolf) oppt;
    						if(wolf.getCopy() != null) {
    							Wolf coppyWolf = wolf.getCopy();
    							tb.opponents.add(coppyWolf);
    							Turn coppyTurn = new Turn(coppyWolf.getOpponentId(), coppyWolf.getSpeed());
    							tb.turnArrList.add(coppyTurn);
    							tb.turnOrder.offer(coppyTurn);
    							coppyWolf = null;
    							wolf.setCopy(null);
    						}
    					}
    					tb.turnOrder.poll();
    					tb.turnOrder.offer(turn);
    					break;
    				}
    			}
    			for(Human humt : tb.characters) {
    				if(humt.getName().equals(tempNameOrId)) {
    					if(humt.isDoubleTurnNext()) {
        					init.menu.turnMoveChar(humt);
        					humt.setDoubleTurnNext(false);
    					}
    					init.menu.turnMoveChar(humt);
    					if(humt.isRun()) {
    						check=false;
    					}
    					if(humt.getTarget() != null) {
    						if(humt.getTarget().getPoints() <= 0) {
    							String name = humt.getTarget().getOpponentId();
    							
    							for(int i = 0; i<tb.turnOrder.size();i++) {
	    							Turn temp2 = tb.turnOrder.poll();
	    							if(name != temp2.getIdOrName()) {	
	    								tb.turnOrder.offer(temp2);
    								}
    							}
    							tb.opponents.remove(humt.getTarget());
    							init.initializeTurnArrList();
    							
    							
    						}
    					}
    					
    					
    					tb.turnOrder.poll();
    					tb.turnOrder.offer(turn);
    					break;
    				}
    			}
    			if(tb.characters.isEmpty()) {
    				System.out.println("Opponents Win");
    				break;
    			}
    			if(tb.opponents.isEmpty()) {
    				System.out.println("Characters Win");
    				break;
    			}
    			
	
    	}
    	
    	
    	
    	
    	
    	
    	
    }
    
    }